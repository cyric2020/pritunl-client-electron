module.exports = {
  key: '',
  version: '1.2.3019.52',
  serviceHost: '127.0.0.1:9770',
  wg: false,
  unixSocket: false,
  unixPath: '/var/run/pritunl.sock'
};
