require('./js/globals.js');
require('./js/init.js');
