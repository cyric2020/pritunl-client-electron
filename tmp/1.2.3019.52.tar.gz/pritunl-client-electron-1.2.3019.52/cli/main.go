package main

import (
	"github.com/pritunl/pritunl-client-electron/cli/cmd"
)

func main() {
	cmd.Execute()
}
