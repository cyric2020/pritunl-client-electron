package constants

const (
	Version = "1.2.3019.52"
)

var (
	Development = false
	Macos10     = false
)
